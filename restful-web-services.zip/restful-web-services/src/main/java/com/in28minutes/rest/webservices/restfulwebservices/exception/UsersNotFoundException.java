package com.in28minutes.rest.webservices.restfulwebservices.exception;

public class UsersNotFoundException extends RuntimeException {

	public UsersNotFoundException(String message) {
		super(message);
	}

}
