package com.in28minutes.rest.webservices.restfulwebservices.exception;

public class CreateUserException extends RuntimeException {

	public CreateUserException(String message) {
		super(message);
	}
}
