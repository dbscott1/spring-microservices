#RESTful Web Services

Social Media Application

Retrieve all Users      - GET   /users
Create a User           - POST  /users
Retrieve a User         - GET   /users/{id}
Delete a User           - DELETE    /users/{id} -> /users/1

Retrieve all posts for a User   - GET /users/{id}/posts
Create a posts for a User       - POST /users/{id}/posts    
Create a posts for a User       - GET /users/{id}/posts/{post_id}